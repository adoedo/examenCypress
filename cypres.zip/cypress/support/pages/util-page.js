class Util{

    loger(log){
        cy.log(log)
    }
}

export default Util